package com.example.indoorenvironmentmonitoringsystem.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;

import com.example.indoorenvironmentmonitoringsystem.R;
import com.example.indoorenvironmentmonitoringsystem.sensorData.RESTAPI;
import com.example.indoorenvironmentmonitoringsystem.sensorData.SensorData;
import com.example.indoorenvironmentmonitoringsystem.sensorData.SensorDataAdapter;
import com.example.indoorenvironmentmonitoringsystem.task.SensorDataAquisition;
import com.example.indoorenvironmentmonitoringsystem.util.PrintUtil;
import com.example.indoorenvironmentmonitoringsystem.vo.AtlasenVO;
import com.example.indoorenvironmentmonitoringsystem.vo.SensorDataVO;
import com.example.indoorenvironmentmonitoringsystem.vo.SensorVO;
import com.google.gson.Gson;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class RecycleViewActivity extends AppCompatActivity {
    Card_View cardview;

    public void getSensorData() {
        // Json parser
        RecyclerView recyclerView = findViewById(R.id.recycleView);

        AtlasenVO<SensorVO> atlasenVO = SensorData.atlasenVO;
        SensorVO sensorVO = atlasenVO.getSensor_list().get(0);
        SensorDataVO dataVO = sensorVO.getData_list();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        SensorDataAdapter adapter = new SensorDataAdapter();



        Field[] fields = dataVO.getClass().getDeclaredFields(); //가지고있는 변수들을 저장
        Method[] methods = dataVO.getClass().getDeclaredMethods();

        for (Field key: fields) {
            key.setAccessible(true);
            try {
                Field f = R.drawable.class.getDeclaredField(key.getName().toLowerCase());
                int id = getResources().getIdentifier(f.getName(), "drawable", this.getPackageName());
                adapter.addItem(new SensorData(id, key.getName(), "d"));
                recyclerView.setAdapter(adapter);
                PrintUtil.print(key.getName());

            } catch (NoSuchFieldException e) {
                PrintUtil.print(e.toString());
            }
        }

        for (Method m:methods) {
            try {
                Object o = m.invoke(dataVO);
                PrintUtil.print(o.toString());
            } catch (IllegalAccessException | InvocationTargetException e) {
                PrintUtil.print(e.getMessage());
            }
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_view);
        getSensorData();
    }
}
