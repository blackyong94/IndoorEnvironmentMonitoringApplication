package com.example.indoorenvironmentmonitoringsystem.sensorData;

public enum SensorEnum {
    co2,

}
