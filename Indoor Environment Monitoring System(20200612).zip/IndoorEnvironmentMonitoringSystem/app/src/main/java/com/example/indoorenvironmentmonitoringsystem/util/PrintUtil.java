package com.example.indoorenvironmentmonitoringsystem.util;

import android.util.Log;

public class PrintUtil {

    public static void print(String msg){
        print("print", msg);
    }

    public static void print(String tag, String msg){
        Log.d(tag, msg);
    }
}
