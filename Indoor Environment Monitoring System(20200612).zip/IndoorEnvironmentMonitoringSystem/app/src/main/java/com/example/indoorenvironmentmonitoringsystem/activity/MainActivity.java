package com.example.indoorenvironmentmonitoringsystem.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.Sensor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.indoorenvironmentmonitoringsystem.R;
import com.example.indoorenvironmentmonitoringsystem.sensorData.RESTAPI;
import com.example.indoorenvironmentmonitoringsystem.sensorData.SensorData;
import com.example.indoorenvironmentmonitoringsystem.task.SensorDataAquisition;

import static com.example.indoorenvironmentmonitoringsystem.util.PrintUtil.*;

import com.example.indoorenvironmentmonitoringsystem.util.PrintUtil;
import com.example.indoorenvironmentmonitoringsystem.vo.AtlasenVO;
import com.example.indoorenvironmentmonitoringsystem.vo.SensorDataVO;
import com.example.indoorenvironmentmonitoringsystem.vo.SensorVO;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    TextView[] viewArr = new TextView[14];
    MainCard_View temp_CardView;
    MainCard_View Hum_CardView;

    public void activityFindID() {
   /*     viewArr[0] = findViewById(R.id.Temp_Textview);
        viewArr[1] = findViewById(R.id.Hum_Textview);*/
        viewArr[2] = findViewById(R.id.PM10_Textview);
        viewArr[3] = findViewById(R.id.PM2_5_Textview);
        viewArr[4] = findViewById(R.id.PM1_0_Textview);
        viewArr[5] = findViewById(R.id.TVOC_Textview);
        viewArr[6] = findViewById(R.id.Co2_Texview);
        viewArr[7] = findViewById(R.id.Co_Textview);
        viewArr[8] = findViewById(R.id.O3_Texview);
        viewArr[9] = findViewById(R.id.NH3_Textview);
        viewArr[10] = findViewById(R.id.HCHO_Texview);
        viewArr[11] = findViewById(R.id.NO2_Textview);
        viewArr[12] = findViewById(R.id.dbA_Textview);
        viewArr[13] = findViewById(R.id.Pir_Textview);
    }

    public void scheduleSensorData() {
        long initialDelay = 0;
        long period = 60;
        TimeUnit unit = TimeUnit.SECONDS;

        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        service.scheduleAtFixedRate(new SensorDataAquisition(this::atlasenSensorDataVO), initialDelay, period, unit);
    }

    /*    public static <T> List<T> getListFromJson(String jsonString, Class<T> cls){
            List<T> list = new ArrayList<>();
            try {
                @SuppressWarnings("unchecked")
                List<LinkedTreeMap<String, Object>> listFromJson = gson.fromJson(jsonString, List.class);
                Iterator<LinkedTreeMap<String, Object>> it = listFromJson.iterator();
                while(it.hasNext()) {
                    Object o = cls.newInstance();
                    ZinBeanTool.copyProperty(it.next(), o);
                    list.add(cls.cast(o));
                }
            }catch(Exception e) {
                e.printStackTrace();
            }
            return list;
        }*/

    public void atlasenSensorDataVO(String result) {
//      REST API 호출하여 불러온 데이터(result)
//        Log.d("print",result);

//        RESTAPI restapi = new RESTAPI(result);
        Gson gson = new Gson();

        AtlasenVO<SensorVO> atlasenVO = gson.fromJson(result, TypeToken.getParameterized(AtlasenVO.class, SensorVO.class).getType());
        SensorData.atlasenVO = atlasenVO;

        SensorVO sensorVO = atlasenVO.getSensor_list().get(0);
        SensorVO sensorVO2 = atlasenVO.getSensor_list().get(1); //2번째 센서


        print(sensorVO.getData_list().getCO2());


//        for (String key : atlasenVO.getSensor_list().get(1).keySet()) {
//            Log.d("print", atlasenVO.getSensor_list().get(1).get(key).toString());
//        }

        temp_CardView = findViewById(R.id.maincardview);
        Hum_CardView = findViewById(R.id.maincardview2);

        temp_CardView.setImage(R.drawable.temp);
        temp_CardView.setName("Temp");
//        temp_CardView.setValue(sensorDataVO.getTemp());

        Hum_CardView.setImage(R.drawable.rh); //수정사항 : 습도 사진 사이즈 줄이기
        Hum_CardView.setName("습도");
//        Hum_CardView.setValue(sensorDataVO.getRH());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activityFindID();

        scheduleSensorData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void titleViewOnClicked(View view) {
        Intent intent = new Intent(getApplicationContext(), RecycleViewActivity.class);
        startActivity(intent);
    }
}