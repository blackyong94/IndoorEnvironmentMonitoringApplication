package com.example.indoorenvironmentmonitoringsystem.vo;

import android.hardware.Sensor;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AtlasenVO<T extends SensorVO> {
    private int rst_code;
    private String update_date;

    private List<T> sensor_list;

    public int getRst_code() {
        return rst_code;
    }

    public String getUpdate_date() {
        return update_date;
    }

    public List<T> getSensor_list() {
        return sensor_list;
    }
}
