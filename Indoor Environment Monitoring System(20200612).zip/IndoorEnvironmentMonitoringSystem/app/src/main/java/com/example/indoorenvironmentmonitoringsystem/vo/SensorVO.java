package com.example.indoorenvironmentmonitoringsystem.vo;

import java.util.Map;

public class SensorVO {
    private String floor;
    private String zone;
    private String sensor;

    private SensorDataVO data_list;

    public String getFloor() {
        return floor;
    }

    public String getZone() {
        return zone;
    }

    public String getSensor() {
        return sensor;
    }

    public SensorDataVO getData_list() {
        return data_list;
    }

}
