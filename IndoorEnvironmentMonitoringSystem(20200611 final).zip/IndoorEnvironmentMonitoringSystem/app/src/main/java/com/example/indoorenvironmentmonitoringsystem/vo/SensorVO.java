package com.example.indoorenvironmentmonitoringsystem.vo;

import com.example.indoorenvironmentmonitoringsystem.SensorData;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.internal.LinkedTreeMap;

import java.util.List;
import java.util.Map;

public class SensorVO {
    private String floor;
    private String zone;
    private String sensor;

    private Map<String, Object> data_list;

    public String getFloor() {
        return floor;
    }

    public String getZone() {
        return zone;
    }

    public String getSensor() {
        return sensor;
    }

    public Map<String, Object> getData_list() {
        return data_list;
    }

}
