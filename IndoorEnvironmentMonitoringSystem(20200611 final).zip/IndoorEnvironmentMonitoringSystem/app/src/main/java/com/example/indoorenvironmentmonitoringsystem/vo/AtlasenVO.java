package com.example.indoorenvironmentmonitoringsystem.vo;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AtlasenVO {
    private int rst_code;
    private String update_date;

    private List<Object> sensor_list;

    public int getRst_code() {
        return rst_code;
    }

    public String getUpdate_date() {
        return update_date;
    }

    public List<Object> getSensor_list() {
        return sensor_list;
    }
}
