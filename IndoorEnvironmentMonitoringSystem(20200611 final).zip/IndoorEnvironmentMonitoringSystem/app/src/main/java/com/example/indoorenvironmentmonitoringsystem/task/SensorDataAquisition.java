package com.example.indoorenvironmentmonitoringsystem.task;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class SensorDataAquisition implements Runnable{

    private Consumer<String> callback;

    public SensorDataAquisition(Consumer<String> callback){
        this.callback = callback;
    }
    @Override
    public void run(){
        // Open the connection
        URL url = null;
        HttpURLConnection conn = null;
        InputStream is = null;
        try {
            url = new URL("http://www.atlasencontrol.com:5001/api/ba265ab638b63dd0e36bb4e1824e62df1d2a4323c04fc4a8806672350537bc1f/realtime/");
            //누적 데이터 호출 URL 끝단에 date
            //URL url = new URL("http://www.atlasencontrol.com:5001/api/ba265ab638b63dd0e36bb4e1824e62df1d2a4323c04fc4a8806672350537bc1f/date/");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            is = conn.getInputStream();

            // Get the stream
            StringBuilder builder = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String line = "";
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }

            callback.accept(builder.toString());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
