package com.example.indoorenvironmentmonitoringsystem.activity;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.indoorenvironmentmonitoringsystem.R;

public class MainCard_View extends LinearLayout {
    ImageView imageView;
    TextView nameTextView;
    TextView valueTextView;


    public MainCard_View(Context context) {
        super(context);
        init(context);
    }

    public MainCard_View(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.main_card_view, this, true);

        imageView = findViewById(R.id.mainImageView);
        nameTextView = findViewById(R.id.mainNameTextVeiw);
        valueTextView = findViewById(R.id.mainValueTextVeiw);
    }

    public void setImage(int resId) {
        imageView.setImageResource(resId);
    }

    public void setName(String name) {
        nameTextView.setText(name);
    }

    public void setValue(String value) {
        valueTextView.setText(value);
    }
}
