package com.example.indoorenvironmentmonitoringsystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SensorDataAdapter extends RecyclerView.Adapter<SensorDataAdapter.ViewHolder> {
    ArrayList<SensorData> items = new ArrayList<SensorData>();

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflater.inflate(R.layout.card_view, viewGroup, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        SensorData item = items.get(position);
        viewHolder.setItem(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void addItem(SensorData item) {
        items.add(item);
    }

    public void setItems(ArrayList<SensorData> items) {
        this.items = items;
    }

    public SensorData getItem(int position) {
        return items.get(position);
    }

    public SensorData setItem(int position, SensorData item) {
        return items.set(position, item);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView sensorImage;
        TextView sensorName;
        TextView sensorValue;

        public ViewHolder(View itemView) {
            super(itemView);

            sensorImage = itemView.findViewById(R.id.sensorImage_ImageView);
            sensorName = itemView.findViewById(R.id.sensorName_TextView);
            sensorValue = itemView.findViewById(R.id.sensorValue_TextView);
        }

        public void setItem(SensorData item) {
            sensorImage.setImageResource(item.getIcon());
            sensorName.setText(item.getKey());
            sensorValue.setText(item.getValue());
        }
    }
}
