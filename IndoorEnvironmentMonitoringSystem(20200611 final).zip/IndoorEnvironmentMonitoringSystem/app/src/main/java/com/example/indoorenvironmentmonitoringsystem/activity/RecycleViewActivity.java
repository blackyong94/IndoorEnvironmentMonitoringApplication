package com.example.indoorenvironmentmonitoringsystem.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.indoorenvironmentmonitoringsystem.R;
import com.example.indoorenvironmentmonitoringsystem.RESTAPI;
import com.example.indoorenvironmentmonitoringsystem.SensorData;
import com.example.indoorenvironmentmonitoringsystem.SensorDataAdapter;
import com.example.indoorenvironmentmonitoringsystem.task.SensorDataAquisition;
import com.example.indoorenvironmentmonitoringsystem.vo.SensorDataVO;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.nio.file.Files;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class RecycleViewActivity extends AppCompatActivity {
    Card_View cardview;

    public void scheduleSensorData() {
        long initialDelay = 0;
        long period = 60;
        TimeUnit unit = TimeUnit.SECONDS;

        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        service.scheduleAtFixedRate(new SensorDataAquisition(this::sensorDataGet), initialDelay, period, unit);
    }

    public void sensorDataGet(String result) {
        // Json parser
        RecyclerView recyclerView = findViewById(R.id.recycleView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        SensorDataAdapter adapter = new SensorDataAdapter();

        adapter.addItem(new SensorData(R.drawable.co2, "CO2", "1204 ppm"));

        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_view);
        scheduleSensorData();
    }
}
