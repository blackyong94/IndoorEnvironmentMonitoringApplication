package com.example.indoorenvironmentmonitoringsystem.vo;

import java.util.List;

public class SensorDataVO {
    private String CO2;
    private String CO;
    private String TVOC;
    private String PM10;
    private String PM25;
    private String PM01;
    private String HCHO;
    private String NO2;
    private String O3;
    private String Temp;
    private String RH;
    private String Lux;
    private String dBA;
    private String NH3;

    private boolean MOTION;

    public String getCO2() {
        return CO2 + "ppm";
    }
    public String getCO() {
        return CO + "ppm";
    }
    public String getTVOC() {
        return TVOC + "ppb";
    }
    public String getPM10() { return PM10 + "ug/㎥"; }
    public String getPM25() {
        return PM25 + "ug/㎥";
    }
    public String getPM01() {
        return PM01 + "ug/㎥";
    }
    public String getHCHO() {
        return HCHO + "ppb";
    }
    public String getNO2() {
        return NO2 + "ppb";
    }
    public String getO3() {
        return O3 + "ppb";
    }
    public String getNH3() {
        return NH3 + "ug/㎥";
    }
    public String getTemp() {
        return Temp + "°C";
    }
    public String getRH() {
        return RH + "%";
    }
    public String getLux() {
        return Lux + "lux";
    }
    public String getdBA() {
        return dBA + "dBA";
    }
    public boolean isMOTION() {
        return MOTION;
    }
    public String[] keyset() {
        String[] key = {CO2, CO, TVOC, PM10, PM25, PM01, HCHO, NO2, O3, Temp, RH, Lux, dBA};
        return key;
    }
}
