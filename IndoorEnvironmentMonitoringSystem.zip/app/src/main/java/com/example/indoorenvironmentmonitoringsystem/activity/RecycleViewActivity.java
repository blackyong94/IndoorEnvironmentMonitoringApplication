package com.example.indoorenvironmentmonitoringsystem.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.indoorenvironmentmonitoringsystem.R;
import com.example.indoorenvironmentmonitoringsystem.Card_View;

public class RecycleViewActivity extends AppCompatActivity {
    Card_View cardview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_view);

        cardview = findViewById(R.id.cardview);
        cardview.setSensorImage(R.drawable.ic_launcher_foreground);
        cardview.setSensorName("Temp");
        cardview.setSensorValue("23.4");
    }


    public void backButtonOnClicked(View view) {
        Intent intent = new Intent(
                getApplicationContext(),
                MainActivity.class);

        startActivity(intent);
    }
}
