package com.example.indoorenvironmentmonitoringsystem.vo;

import com.google.gson.JsonArray;

public class SecondDataVO {
    private String floor;
    private String zone;
    private String sensor;

    private JsonArray data_list;
}
