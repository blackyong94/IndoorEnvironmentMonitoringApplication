package com.example.indoorenvironmentmonitoringsystem.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.indoorenvironmentmonitoringsystem.R;
import com.example.indoorenvironmentmonitoringsystem.RESTAPI;
import com.example.indoorenvironmentmonitoringsystem.task.SensorDataAquisition;
import com.google.gson.JsonObject;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    TextView[] viewArr = new TextView[14];
/*  {Temptxt, Humtxt, PM10txt, PM25txt, PM01txt, TVOCtxt , CO2txt
            ,COtxt , O3txt, NH3txt, HCHOtxt, NO2txt, dBAtxt, PIRtxt};*/

/*    public void activityFindID(){
        Temptxt = findViewById(R.id.Temp_Textview);
        Humtxt = findViewById(R.id.Hum_Textview);
        PM10txt = findViewById(R.id.PM10_Textview);
        PM25txt = findViewById(R.id.PM2_5_Textview);
        PM01txt = findViewById(R.id.PM1_0_Textview);
        TVOCtxt = findViewById(R.id.TVOC_Textview);
        CO2txt = findViewById(R.id.Co2_Texview);
        COtxt = findViewById(R.id.Co_Textview);
        O3txt = findViewById(R.id.O3_Texview);
        NH3txt = findViewById(R.id.NH3_Textview);
        HCHOtxt = findViewById(R.id.HCHO_Texview);
        NO2txt = findViewById(R.id.NO2_Textview);
        dBAtxt = findViewById(R.id.dbA_Textview);
        PIRtxt = findViewById(R.id.Pir_Textview);
    }*/
/*
    public void ChangedTextView(JsonObject data_list){
        Temptxt.setText(data_list.get("Temp").toString());
        Humtxt.setText(data_list.get("Hum").toString());
        PM10txt.setText(data_list.get("PM10").toString());
        PM25txt.setText(data_list.get("PM25").toString());
        PM01txt.setText(data_list.get("PM01").toString());
        TVOCtxt.setText(data_list.get("TVOC").toString());
        CO2txt.setText(data_list.get("CO2").toString());
        COtxt.setText(data_list.get("CO").toString());
        O3txt.setText(data_list.get("O3").toString());
        NH3txt.setText(data_list.get("NH3").toString());
        HCHOtxt.setText(data_list.get("HCHO").toString());
        NO2txt.setText(data_list.get("NO2").toString());
        dBAtxt.setText(data_list.get("dBA").toString());
        PIRtxt.setText(data_list.get("MOTION").toString());
    }
*/
    public void activityFindID(){

        viewArr[0] = findViewById(R.id.Temp_Textview);
        viewArr[1] = findViewById(R.id.Hum_Textview);
        viewArr[2] = findViewById(R.id.PM10_Textview);
        viewArr[3] = findViewById(R.id.PM2_5_Textview);
        viewArr[4] = findViewById(R.id.PM1_0_Textview);
        viewArr[5] = findViewById(R.id.TVOC_Textview);
        viewArr[6] = findViewById(R.id.Co2_Texview);
        viewArr[7] = findViewById(R.id.Co_Textview);
        viewArr[8] = findViewById(R.id.O3_Texview);
        viewArr[9] = findViewById(R.id.NH3_Textview);
        viewArr[10] = findViewById(R.id.HCHO_Texview);
        viewArr[11] = findViewById(R.id.NO2_Textview);
        viewArr[12] = findViewById(R.id.dbA_Textview);
        viewArr[13] = findViewById(R.id.Pir_Textview);
    }
    public void changeTextView(String result){
//      REST API 호출하여 불러온 데이터(result)
        Log.d("print",result);

        RESTAPI restapi = new RESTAPI(result);
        JsonObject data_list = restapi.get();

        Log.d("print", data_list.keySet().getClass().toString());
        for (String key : data_list.keySet()) {
//                        Log.d("print", key);
            Log.d("print",key + " = " + data_list.get(key).toString());
//            Log.d("print",key + " = " + data_list.get(key).getClass().toString());
        }

        int i = 0;
        for (String key: data_list.keySet()) {
            if(i<=13) {
                viewArr[i].setText(data_list.get(key).toString());
                i++;
            } else {
                break;
            }
        }
    }
    public void scheduleSensorData(){
        long initialDelay = 0;
        long period = 60;
        TimeUnit unit = TimeUnit.SECONDS;

        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        service.scheduleAtFixedRate(new SensorDataAquisition(this::changeTextView), initialDelay, period, unit);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activityFindID();
//        안드로이드에서는 HttpURL Library 사용시 쓰레드를 사용해야함
//        Thread thread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    String result = null;
//
//                    // Open the connection
//                    URL url = new URL("http://www.atlasencontrol.com:5001/api/ba265ab638b63dd0e36bb4e1824e62df1d2a4323c04fc4a8806672350537bc1f/realtime/");
////                    누적 데이터 호출 URL 끝단에 date
////                    URL url = new URL("http://www.atlasencontrol.com:5001/api/ba265ab638b63dd0e36bb4e1824e62df1d2a4323c04fc4a8806672350537bc1f/date/");
//
//                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//                    conn.setRequestMethod("POST");
//                    InputStream is = conn.getInputStream();
//
//                    // Get the stream
//                    StringBuilder builder = new StringBuilder();
//                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
//                    String line = "";
//                    while ((line = reader.readLine()) != null) {
//                        builder.append(line);
//                    }
//
//                    // Set the result
//                    result = builder.toString();
//

//
//
//                } catch (Exception e) {
//                    Log.e("print", "POST method failed: " + e.getMessage());
//                    e.printStackTrace();
//                }
//            }
//        });
//        thread.start();

        scheduleSensorData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void titleViewOnClicked(View view) {
        Intent intent = new Intent(
                getApplicationContext(),
                RecycleViewActivity.class);

        startActivity(intent);

    }
}