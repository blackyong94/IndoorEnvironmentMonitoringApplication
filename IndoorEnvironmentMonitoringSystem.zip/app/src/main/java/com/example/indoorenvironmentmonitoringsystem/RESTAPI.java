package com.example.indoorenvironmentmonitoringsystem;

import android.util.Log;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class RESTAPI {
    String result;

    public RESTAPI(String result) {
        this.result = result;
    }

    public JsonObject get( ){
        JsonParser jsonparser = new JsonParser();
        JsonObject jsonObj = (JsonObject) jsonparser.parse(result);
        JsonArray jsonObjectToJsonArray_sensor_list = (JsonArray) jsonObj.get("sensor_list");
        JsonObject sensor_id_1 = (JsonObject) jsonObjectToJsonArray_sensor_list.get(0);
        JsonObject data_list = (JsonObject) sensor_id_1.get("data_list");

        return data_list;
    }
}


