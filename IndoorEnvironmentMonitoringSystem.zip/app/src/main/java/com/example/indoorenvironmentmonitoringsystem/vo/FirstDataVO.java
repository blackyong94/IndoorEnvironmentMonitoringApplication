package com.example.indoorenvironmentmonitoringsystem.vo;

import java.util.List;

public class FirstDataVO {
    private int rst_code;
    private String update_date;

    private List<SecondDataVO> sensor_list;
}
