package com.example.indoorenvironmentmonitoringsystem;

import android.view.View;

import com.example.indoorenvironmentmonitoringsystem.activity.RecycleViewActivity;

public class SensorDataAdapter {

}
