package com.example.indoorenvironmentmonitoringsystem;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class Card_View extends LinearLayout {

    ImageView sensorImage;
    TextView sensorName;
    TextView sensorValue;

    public Card_View(Context context) {
        super(context);
    }

    public Card_View(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    private void init(Context context){
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.card_view, this, true);

        sensorImage.findViewById(R.id.sensorImage_ImageView);
        sensorName.findViewById(R.id.sensorName_TextView);
        sensorValue.findViewById(R.id.sensorValue_TextView);
    }
    public void setSensorImage(int resId){
        sensorImage.setImageResource(resId);
    }
    public void setSensorName(String name){
        sensorName.setText(name);
    }
    public void setSensorValue(String value){
        sensorValue.setText(value);
    }
}
