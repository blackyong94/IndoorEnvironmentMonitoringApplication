package com.example.indoorenvironmentmonitoringsystem;

import android.media.Image;

public class SensorData {
    Image icon;
    String key;
    String value;

    public SensorData(Image icon, String key, String value){
        this.icon = icon;
        this.key = key;
        this.value = value;
    }
}
