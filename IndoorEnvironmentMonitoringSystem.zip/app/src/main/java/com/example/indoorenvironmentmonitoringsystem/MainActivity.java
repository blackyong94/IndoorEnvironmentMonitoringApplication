package com.example.indoorenvironmentmonitoringsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView Temptxt, Humtxt, PM10txt, PM25txt, PM01txt, TVOCtxt , CO2txt
            ,COtxt , O3txt, NH3txt, HCHOtxt, NO2txt, dBAtxt, PIRtxt;


    public void ActivityFindID(){
        Temptxt = findViewById(R.id.Temp_Textview);
        Humtxt = findViewById(R.id.Hum_Textview);
        PM10txt = findViewById(R.id.PM10_Textview);
        PM25txt = findViewById(R.id.PM2_5_Textview);
        PM01txt = findViewById(R.id.PM1_0_Textview);
        TVOCtxt = findViewById(R.id.TVOC_Textview);
        CO2txt = findViewById(R.id.Co2_Texview);
        COtxt = findViewById(R.id.Co_Textview);
        O3txt = findViewById(R.id.O3_Texview);
        NH3txt = findViewById(R.id.NH3_Textview);
        HCHOtxt = findViewById(R.id.HCHO_Texview);
        NO2txt = findViewById(R.id.NO2_Textview);
        dBAtxt = findViewById(R.id.dbA_Textview);
        PIRtxt = findViewById(R.id.Pir_Textview);
    }

    public void ChangedTextView(JsonObject data_list){
        Temptxt.setText(data_list.get("Temp").toString());
//        Humtxt.setText(data_list.get("Hum").toString());
        PM10txt.setText(data_list.get("PM10").toString());
        PM25txt.setText(data_list.get("PM25").toString());
        PM01txt.setText(data_list.get("PM01").toString());
        TVOCtxt.setText(data_list.get("TVOC").toString());
        CO2txt.setText(data_list.get("CO2").toString());
        COtxt.setText(data_list.get("CO").toString());
        O3txt.setText(data_list.get("O3").toString());
        NH3txt.setText(data_list.get("NH3").toString());
        HCHOtxt.setText(data_list.get("HCHO").toString());
        NO2txt.setText(data_list.get("NO2").toString());
        dBAtxt.setText(data_list.get("dBA").toString());
        PIRtxt.setText(data_list.get("MOTION").toString());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityFindID();

//        안드로이드에서는 HttpURL Library 사용시 쓰레드를 사용해야함
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String result = null;

                    // Open the connection
                    URL url = new URL("http://www.atlasencontrol.com:5001/api/ba265ab638b63dd0e36bb4e1824e62df1d2a4323c04fc4a8806672350537bc1f/realtime/");
//                    누적 데이터 호출 URL 끝단에 date
//                    URL url = new URL("http://www.atlasencontrol.com:5001/api/ba265ab638b63dd0e36bb4e1824e62df1d2a4323c04fc4a8806672350537bc1f/date/");

                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    InputStream is = conn.getInputStream();

                    // Get the stream
                    StringBuilder builder = new StringBuilder();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        builder.append(line);
                    }

                    // Set the result
                    result = builder.toString();

//                   REST API 호출하여 불러온 데이터(result)
                    Log.d("print",result);

                    RESTAPI restapi = new RESTAPI(result);
                    JsonObject data_list = restapi.get();

                    Log.d("print", data_list.keySet().getClass().toString());
                    for (String key : data_list.keySet()) {
//                        Log.d("print", key);
                        Log.d("print",key + " = " + data_list.get(key).toString());
                    }

                    ChangedTextView(data_list);

                } catch (Exception e) {
                    Log.e("print", "POST method failed: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}