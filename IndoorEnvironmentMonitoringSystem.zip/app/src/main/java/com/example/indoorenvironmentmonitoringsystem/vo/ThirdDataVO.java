package com.example.indoorenvironmentmonitoringsystem.vo;

public class ThirdDataVO {
    private int CO2, CO, TVOC, PM10, PM25, PM01, HCHO, NO2, O3, Temp, RH, Lux, dBA;
    private boolean MOTION;
}
